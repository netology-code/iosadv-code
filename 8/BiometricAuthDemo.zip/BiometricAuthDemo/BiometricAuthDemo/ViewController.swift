//
//  ViewController.swift
//  BiometricAuthDemo
//
//  Created by Egor Petrov on 08.08.2021.
//

import UIKit
import LocalAuthentication

// Данный пример выполнен как сильно упрощенный способ авторизации в различных банках
class ViewController: UIViewController {

    // Кнопка для ручного вызова авторизации
    @IBOutlet var authButton: UIButton!

    // Контекст LocalAuthentication
    let laContext = LAContext()
    
    // Получатель ошибок
    var error: NSError?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Делаем кнопку ручного запуска доступной, если есть доступ к биометрии
        authButton.isEnabled = laContext.canEvaluatePolicy(
            .deviceOwnerAuthenticationWithBiometrics,
            error: &error
        )

        // Пробуем запросить доступ к биометрии если запускаем первый раз + авторазация если есть доступ
        self.auth()
    }

    // Ручной запуск авторизации
    @objc
    private func handleTap() {
        self.auth()
    }

    func auth() {
        laContext.evaluatePolicy(
            .deviceOwnerAuthenticationWithBiometrics,
            localizedReason: "To access data"
        ) { success, error in
            if let error = error {
                print("Try another method, \(error.localizedDescription)")
                return
            }

            print("Auth: \(success)")
        }
    }
}

